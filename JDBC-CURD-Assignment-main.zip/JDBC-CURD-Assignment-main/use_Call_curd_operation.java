package JDBC_codes;


public class use_Call_curd_operation {
    public static void main(String args[]){
        Call_curd_operation call=new Call_curd_operation();
//        call.read();
//        call.insert(2, "Jatin", "Kesarwani", "Chakghat", 2);
//        call.read();
//        call.updateCity(1, "Prayagraj");
//        call.read();
//        call.updateProjectID(2, 8);
//        call.read();
//        call.delete(2);
//        System.out.println("After Deletion");
//        call.read();
//        call.getEmpProjID(1);
//        call.getEmpCity(1);
        call.getEmpName(4);
            
    }
}


